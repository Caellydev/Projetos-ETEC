using System;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Preenchendo o comboBox com categorias como no segundo exemplo
            string[] categorias =
            {
                "Pe�as de corpo inteiro",
                "Acess�rios",
                "Casacos",
                "Pe�as inferiores",
                "Camisetas",
                "Cal�ados"
            };

            comboBox1.Items.AddRange(categorias);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = textBox1.Text.Trim();
            string precoTexto = textBox2.Text.Trim();
            string categoriaSelecionada = comboBox1.SelectedItem?.ToString();
            bool estaDisponivel = checkBox1.Checked;
            DateTime validade = dateTimePicker1.Value;

            // Valida��o do nome
            if (string.IsNullOrWhiteSpace(nome))
            {
                MessageBox.Show("O nome do produto n�o pode ser vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Valida��o do pre�o
            if (string.IsNullOrWhiteSpace(precoTexto) || !decimal.TryParse(precoTexto, out decimal preco) || preco <= 0)
            {
                MessageBox.Show("O pre�o deve ser um n�mero maior que zero e n�o pode estar vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Valida��o da data de validade
            if (validade <= DateTime.Now)
            {
                MessageBox.Show("A data de validade deve ser maior que a data atual.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Mensagem de sucesso
            MessageBox.Show($"Produto {nome} cadastrado com sucesso! " +
                            $"Pre�o: R$ {preco:F2}. Categoria: {categoriaSelecionada}. " +
                            $"Dispon�vel: {(estaDisponivel ? "Sim" : "N�o")}. " +
                            $"Data de Validade: {validade.ToShortDateString()}",
                            "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Limpando os campos do formul�rio
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.SelectedIndex = -1;
            checkBox1.Checked = false;
            dateTimePicker1.Value = DateTime.Now;
        }
    }
}
